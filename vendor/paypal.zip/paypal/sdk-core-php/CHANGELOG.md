
# CHANGELOG


## V1.4.2 (September 11, 2013)

   * Adding new mandatory parameters - client id & secret to open id classes
   * Adding new default scope for [Seamless checkout permission](https://developer.paypal.com/webapps/developer/docs/integration/direct/log-in-with-paypal/detailed/#seamlesscheckout) in PPOpenIdSession::getAuthorizationUrl() function


## V1.4.0 (April 26, 2013)


   * Adding support for Openid Connect

